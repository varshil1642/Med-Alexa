<?php
session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "medalexa";

    // Create connection
    $con = new mysqli($servername, $username, $password, $dbname);
    // $_SESSION['info'] = "";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

    <style>
    .input-group {
        width: 30vw;
    }

    .input-group-text {
        width: 78px;
    }

    .ro {
        background-color: white !important;
    }

    .bt {
        width: 120px;
    }

    .alert {
        width: 30vw;
        margin: 0px auto;
    }

    .label {
        width: 5.5vw;
        display: block;
    }
    </style>

</head>

<body>
    <?php require("doctor-nav.php") ?>
    <form class="container d-flex align-items-center justify-content-center py-5" action="doctor.php" method="post">
        <div class="input-group">
            <input name="pid" class="form-control" type="search" placeholder="Search patients by patient ID"
                aria-label="Search" required>
            <button class="btn btn-outline-secondary " name="btn" type="submit"><i class="bi bi-search"></i></button>
        </div>
    </form>
    <?php
        
        if(isset($_POST["btn"]))
        {
            $pid = $_POST["pid"];
        $search = "SELECT * FROM patient WHERE id='$pid'";
        // $res = mysqli_query($con,$update);
        $res = $con->query($search);
        if (mysqli_num_rows($res) > 0)
        {
            $result = mysqli_fetch_assoc($res);
            $pname = $result['name'];
            $dob = $result['dob'];
            $age = $result['age'];
            $pemail = $result['email'];
            $pphone = $result['phone'];
                // echo gettype($pemail);
                $_SESSION['pt_email'] = $pemail;
                $_SESSION['pt_id'] = $pid;
                $_SESSION['dr_id'] = $_SESSION['id'];

                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                echo 'Patient ID found.';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                echo '</div>';
            }
            else
            {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                echo 'Patient ID not found!';
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                echo '</div>';
            }
        }
    ?>
    <div class="f container d-flex flex-column align-items-center justify-content-center py-5">
        <div class="input-group mb-3">
            <span class="input-group-text label">P-ID</span>
            <input id="pid" type="text" class="ro form-control" placeholder="Patient-ID" readonly>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text label">Name</span>
            <input id="name" type="text" class="ro form-control" placeholder="Patient's Name" readonly>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text label">DOB</span>
            <input id="dob" type="text" class="ro form-control" placeholder="Patient's DOB" readonly>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text label">Age</span>
            <input id="age" type="text" class="ro form-control" placeholder="Patient's Age" readonly>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text label">Email-ID</span>
            <input id="email" type="email" class="ro form-control" placeholder="Patient's Email-ID" readonly>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text label">Phone</span>
            <input id="phone" type="tel" class="ro form-control" placeholder="Patient's Phone Number" readonly>
        </div>
            Search for a patient ID above to see their data
        </div>
        <div class="container d-flex align-items-center justify-content-center">
            <a type="button" class="bt btn btn-primary mx-2" href="">Report</a>
            <a type="button" class="bt btn btn-primary mx-2" href="prescription.php">Prescription</a>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <script>
    pid = document.getElementById("pid");
    pname = document.getElementById('name');
    pdob = document.getElementById('dob');
    page = document.getElementById('age');
    pgender = document.getElementById('phone');
    pemail = document.getElementById('email');

    ppid = "<?php echo $pid; ?>";
    ppname = "<?php echo $pname; ?>";
    ppdob = "<?php echo $dob; ?>";
    ppage = "<?php echo "$age"; ?>";
    ppgender = "<?php echo "$pphone"; ?>";
    ppemail = "<?php echo "$pemail"; ?>";

    // console.log(ppid);
    // console.log(typeof ppid);
    // console.log(ppname);
    // console.log(typeof ppname);
    // console.log(ppage);
    // console.log(typeof ppage);
    // console.log(ppgender);
    // console.log(typeof ppgender);
    // console.log(ppemail);
    // console.log(typeof ppemail);

    pid.value = ppid;
    pname.value = ppname;
    pgender.value = ppgender;
    page.value = ppage;
    pdob.value = ppdob;
    pemail.value = ppemail;
    </script>

</body>
</html>