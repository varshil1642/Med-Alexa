<?php include("AllphpFunctions.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Signup Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
    body {
        background-color: #6665ee;
        font-family: 'Poppins', sans-serif;
    }

    .signup {
        background-color: white;
        width: 40vw;
        margin: 5vh auto;
        border: 5px solid black;
        padding: 5vh 5vw;
        border-radius: 50px;
        /* box-shadow: 0px 5px 20px 2px black; */
        overflow: auto;
    }

    @media only screen and (max-width: 600px) {
        .signup {
            width: 90vw;
            margin: 3vh;
        }
    }

    .user {
        margin-right: 15vw;
    }
    </style>
</head>

<body>
    <div class="signup">
        <form class="row g-3" action="signup-user.php" method="POST" autocomplete="">
            <h2 class="text-center">Signup Form</h2>
            <?php
                if(count($errors) > 0){
            ?>
                <div class="alert alert-danger text-center">
                <?php  
                    foreach($errors as $error){
                        echo $error;
                        echo "<br>";
                    }
                ?>
                </div>
            <?php
                }
            ?>
            <div class="col-md-4 user">
                <label for="inputuser" class="form-label">Select User Type</label>
                <select id="inputuser" class="form-select" name="inputUser">
                    <option>doctor</option>
                    <option selected>operator</option>
                    <option>pharmacist</option>
                    <option>pathologist</option>
                </select>
            </div>
            <div class="specification" name="specification" id="specification">
                <label for="inputdtype" class="form-label">Select Doctor Type</label>
                <select class="form-select" id="inputDtype" name="inputDtype">
                    <option selected>Cardiologist</option>
                    <option>Audiologist</option>
                    <option>Dentis</option>
                    <option>ENT specialist</option>
                    <option>Orthopaedic surgeon</option>
                    <option>Paediatrician</option>
                    <option>Psychiatrists</option>
                    <option>Veterinarian</option>
                    <option>Radiologist</option>
                    <option>Pulmonologist</option>
                    <option>Endocrinologist</option>
                    <option>Oncologist</option>
                    <option>Cardiothoracic surgeon</option>

                </select>
            </div>
            <div class="col-12 user" id="name">
                <label for="inputname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="inputname" name="inputName" placeholder="">
            </div>
            <div class="col-md-6 " id="email">
                <label for="inputEmail4" class="form-label">Email</label>
                <input type="email" class="form-control" name="inputEmail" id="inputEmail">
            </div>
            <div class="col-md-6" id="call">
                <label for="inputNumber" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" name="inputPhone" id="inputPhone">
            </div>
            <div class="col-md-6" id="pass">
                <label for="inputPassword4" class="form-label">Password</label>
                <input type="password" class="form-control" name="inputPassword" id="inputPassword">
            </div>
            <div class="col-md-6" id="repass">
                <label for="RePassword4" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" name="RePassword" id="RePassword">
            </div>
            <div class="col-12 btn">
                <button type="submit" id="signupsubmit" class="btn btn-primary" name="signup">Sign Up</button>
            </div>
            <div class="fs-5 text-center">Already have an account? <a href="login-user.php">Login here</a></div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script>
    var user = document.getElementById("inputuser");
    var block = document.getElementById("specification");
    setInterval(function() {
        if (user.value == "doctor") {
            console.log(user.value);
            block.style.display = "block";
        } 
        else {
            block.style.display = "none";
        }
    }, 100);
    </script>
</body>

</html>