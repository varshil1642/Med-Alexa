<?php
    session_start();
    $error = array();
    $_SESSION['info']="";
    $con = mysqli_connect('localhost', 'root', '', 'medalexa');
    if(isset($_POST["search"]))
    {
        $pid = $_POST["pid"];
        $search = "SELECT * FROM patient WHERE id='$pid'";
        // $res = mysqli_query($con,$update);
        $res = $con->query($search);
        if (mysqli_num_rows($res) > 0)
        {
            $result = mysqli_fetch_assoc($res);
            $pname = $result['name'];
            $dob = $result['dob'];
            $age = $result['age'];
            $pemail = $result['email'];
            $pphone = $result['phone'];
        }
        else{
            $error['query']="error while updating data";
        }
    }
    if(isset($_POST['delete']))
    {
        $id=$_POST['id'];
        $delete = "DELETE FROM `patient` WHERE `id` = '$id'";
        if(!($con->query($delete)))
        {
            $error['delete']= "Error While deleting account";
        }
    }
    if (isset($_POST['update'])) {
        $id = $_POST['pid'];
        $name = $_POST['pname'];
        $email = $_POST['pemail'];
        $phone = $_POST['pphone'];
        $dob = $_POST['dob'];
        $age = $_POST['age']; 
        $otp=rand(99999,999999);
        // $update = "UPDATE $type SET email = '$email', name = '$name', phone='$phone' WHERE id='$id'";
        // $res = $con->query($update);
        // if ($res == true) {
                $from="team.medalexa@gmail.com";
                $fromName="Team Med-Alexa";
                $subject="OTP for registration to Med-Alexa";
                $headers="Content-Type: text/html; charset=UTF-8\r\n";
                $message=" <p> Your One Time Password (OTP) for update Profile in Med-Alexa <b>Patient</b> is <b>$otp</b><br>
                    Do not share this OTP with anyone.<br><br>Team Med-alexa";
                if(mail($email, $subject, $message, $headers)){
                    $info = "We've sent a verification code to your email - '$email'";
                    $_SESSION['info'] = $info;
                    $_SESSION['pid'] = $id;
                    $_SESSION['pemail'] = $email;
                    $_SESSION['pname'] = $name;
                    $_SESSION['pphone'] = $phone;
                    $_SESSION['dob'] = $dob;
                    $_SESSION['age'] = $age;
                    $_SESSION['otp'] = $otp; 
                    header('location: patient-update-otp.php');
                    exit();
                }
                else{
                    $errors['otp-error'] = "Failed while sending code!";
                }
            // }
        // } 
    }
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
    .profile {
        width: 30vw;
        margin: 5vh auto;
    }

    .label {
        width: 7vw;
        display: block;
    }

    .input-group-text {
        width: 78px;
    }

    .searchbar {
        display: flex;
    }

    .button {
        width: 3vw;
    }

    .ro {
        background-color: white !important;
    }

    .bt {
        width: 240px;
    }

    .fsize {
        font-size: 15px;
    }
    </style>
    <title>Profile</title>
</head>

<body>
    <?php
        if($_SESSION['type'] == 'doctor')
            require("doctor-nav.php");
        else
            require("operator-nav.php");
    ?>

    <div class="profile">
        <h2 class="text-center">Patient Profile </h2>
        <form class="container d-flex align-items-center justify-content-center py-5" action="patient-profile.php"
            method="post">
            <div class="input-group">
                <input name="pid" class="form-control" type="search" placeholder="Search patients by patient ID"
                    aria-label="Search" required>
                <button class="btn btn-outline-secondary " name="search" type="submit"><i
                        class="bi bi-search"></i></button>
            </div>
        </form>
        <?php 
                if(isset($_SESSION['info']) && $_SESSION['info']!= null)
                {
                    ?>
        <div class="alert alert-success text-center">
            <?php echo $_SESSION['info'];?>
        </div>
        <?php
                }
                ?>
        <form class="" action="patient-profile.php" method="POST">
            <div class="input-group mb-3">
                <div class="input-group-text label">ID</div>
                <input id="pid" type="text" class="form-control" name="pid" placeholder="Patient ID" readonly>
            </div>
            <div class="input-group mb-3">
                <div class="input-group-text label">Name</div>
                <input id="name" type="text" class="ro form-control" placeholder="Patient's Name" name="pname">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-text label">DOB</div>
                <input id="dob" type="date" class="ro form-control" placeholder="Patient's DOB" name="dob">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-text label">Age</div>
                <input id="age" type="text" class="ro form-control" placeholder="Patient's Age" name="age">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-text label">Email</div>
                <input id="email" type="email" class="ro form-control" placeholder="Patient's Email-ID" name="pemail">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-text label">Phone</div>
                <input id="phone" type="tel" class="ro form-control" placeholder="Patient's Gender" name="pphone">
            </div>
            <div class="col-12 btn d-flex align-items-center justify-content-around">
                <button type="submit" id="update" class="btn btn-primary" name="update">Update</button>
                <button type="submit" id="delete" class="btn btn-primary" name="delete">Delete</button>
            </div>
        </form>
    </div>
    <script>
    pid = document.getElementById("pid");
    pname = document.getElementById('name');
    pdob = document.getElementById('dob');
    page = document.getElementById('age');
    pgender = document.getElementById('phone');
    pemail = document.getElementById('email');

    ppid = "<?php echo $pid; ?>";
    ppname = "<?php echo $pname; ?>";
    ppdob = "<?php echo $dob; ?>";
    ppage = "<?php echo "$age"; ?>";
    ppgender = "<?php echo "$pphone"; ?>";
    ppemail = "<?php echo "$pemail"; ?>";

    // console.log(ppid);
    // console.log(typeof ppid);
    // console.log(ppname);
    // console.log(typeof ppname);
    // console.log(ppage);
    // console.log(typeof ppage);
    // console.log(ppgender);
    // console.log(typeof ppgender);
    // console.log(ppemail);
    // console.log(typeof ppemail);

    pid.value = ppid;
    pname.value = ppname;
    pgender.value = ppgender;
    page.value = ppage;
    pdob.value = ppdob;
    pemail.value = ppemail;
    // function searchDisplay()
    // {
    // }
    </script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

</body>

</html>