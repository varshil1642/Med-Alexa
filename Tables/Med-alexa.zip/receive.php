<?php
    session_start();
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\SMTP;
    $server= "localhost";
    $username = "root";
    $password = "";
    $db = "medalexa";

    $con = mysqli_connect($server,$username,$password,$db);
    
    $jsonString = file_get_contents("php://input");
    $object = json_decode($jsonString, true);
    
    require("fpdf/fpdf.php");
    require("vendor/autoload.php");
    $pdf=new FPDF();
    $pdf->AddPage();
    $pdf->SetFont("Arial","B",22);
    $pdf->Cell(0,10,"Prescription",1,1,'C');
    $pdf->Ln();
    $pdf->SetFont("Arial","",16);
    $pdf->Cell(30,10,"Sno.",0,0);
    $pdf->Cell(60,10,"Medicine",0,0);
    $pdf->Cell(40,10,"Quantity",0,0);
    $pdf->Cell(30,10,"Dosage",0,1);
    $pdf->Ln();
    for($i=0;$i<count($object);$i++)
    {
        $pdf->Cell(30,10,$i+1,0,0);
        $pdf->Cell(60,10,$object[$i][0],0,0);
        $pdf->Cell(40,10,$object[$i][1],0,0);
        $pdf->Cell(30,10,$object[$i][2],0,0);
        
        $pdf->Ln();
    }
    $pdf->Ln();
    $pdf->SetFont("Arial","",18);
    $pdf->Cell(0,10,"-----Get Well Soon-----",0,0,'C');

    $mail=new PHPMailer();
    $mail->HOST = 'smtp.gmail.com';
    $mail->SMTPAuth= true;
    $mail->SMTPSecure='ssl';
    $mail->Port=587;
    $mail->Username="team.medalexa@gmail.com";
    $mail->Password="Medalexa@162410";
    $mail->From="team.medalexa@gmail.com";
    $mail->FromName="Team Med-Alexa";
    $mail->addAddress($_SESSION['pt_email']);
    $mail->Subject="Prescription by Med-Alexa";
    $mail->Body="Here is your Prescription, Please go through it";

    $doc=$pdf->Output('S');
    $mail->AddStringAttachment($doc,'prescription.pdf','base64','php_demo/pdf');
    if($mail->send())
    {
        echo "<br>Successfull !";
    }
    else{
        echo "Error Occured : ".$mail->ErrorInfo;
    }

    //storing pdf to database
    $doc=$pdf->Output('S');
    
    //this is to add pdf on database
    $pname=$_SESSION['pt_id']."-".rand(99,999);
    $content=$pdf->Output('prescription.pdf','S');

    $did=$_SESSION['dr_id'];
    $pid=$_SESSION['pt_id'];
    
    $sql = "INSERT INTO `prescription` (`pid`, `did`, `json`, `dt`) VALUES ( '$pid' , '$did' , '$jsonString', current_timestamp())";
    if($con->query($sql))
    echo "SUCCESS";
?>