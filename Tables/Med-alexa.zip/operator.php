<?php
    $_SESSION['info']='';
    include("AllphpFunctions.php");
    $erros = array();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operator</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <style>
    .signup {
        width: 40vw;
        margin: 8vh auto;
        border: 5px solid black;
        padding: 5vh 5vw;
        border-radius: 50px;
        /* box-shadow: 0px 5px 20px 2px black; */
        overflow: auto;
    }

    @media only screen and (max-width: 600px) {
        .signup {
            width: 90vw;
            margin: 3vh;
        }
    }

    .user {
        margin-right: 15vw;
    }
    </style>
</head>

<body>
    <?php include("operator-nav.php")?>
    <div class="signup">
        <?php
                if(count($errors) > 0){
            ?>
        <div class="alert alert-danger text-center">
            <?php  
                    foreach($errors as $error){
                        echo $error;
                        echo "<br>";
                    }
                ?>
        </div>
        <?php
                }
            ?>
        <form class="row g-3" action="operator.php" method="POST">
            <h2 class="text-center">Patient Signup Form</h2>
            <div class="col-12 user" id="name">
                <label for="inputname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="Name" name="Name" placeholder="">
            </div>
            <div class="col-6" id="date">
                <label for="inputDob" class="form-label">Date Of Birth</label>
                <input type="date" class="form-control" id="Dob" name="Dob" placeholder="">
            </div>
            <div class="col-6" id="age">
                <label for="inputAge" class="form-label">Age</label>
                <input type="text" class="form-control" id="Age" name="Age" placeholder="">
            </div>
            <div class="col-md-6 " id="email">
                <label for="inputEmail4" class="form-label">Email</label>
                <input type="email" class="form-control" name="Email" id="Email">
            </div>
            <div class="col-md-6" id="call">
                <label for="inputNumber" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" name="Phone" id="Number">
            </div>
            <div class="col-12">
                <button type="submit" id="signupsubmit" class="btn btn-primary" name="patient-otp">Sign Up</button>
            </div>
        </form>
    </div>


    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>