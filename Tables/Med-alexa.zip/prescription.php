<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prescription</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        .myflex{
            width: 45vmin;
            margin: 0px auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        form{
            width: 100%;
            margin: 0px auto;
        }
        .myflex input{
            width: 35vmin;
        }
        .btnflex{
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>

<body>
    <?php include("doctor-nav.php");?>
    <div class="container my-4">
        <form action="prescription.php" method="POST">
            <div class="mb-3 myflex">
                <label for="medicine" class="form-label">Medicine</label>
                <input type="text" class="form-control input" id="medicine" name="medicine" placeholder="Medicine" aria-describedby="medicine" onclick=record(id) required>
            </div>
            <div class="mb-3 myflex">
                <label for="quantity" class="form-label">Quantity</label>
                <input type="number" class="form-control input" id="quantity" name="quantity" placeholder="Quantity" aria-describedby="quantity" onclick=record(id) required>
            </div>
            <div class="mb-3 myflex">
                <label for="dosage" class="form-label">Dosage</label>
                <input type="text" class="form-control input" id="dosage" name="dosage" placeholder="Dosage ex: 101" aria-describedby="dosage" onclick=record(id) required>
            </div>
            <div class="mb-3 btnflex">
                <div class="btncontainer">
                    <button type="submit" id="add" name="add" class="btn btn-primary">Add</button>
                    <button type="reset" id="clear" class="btn btn-primary">Clear</button>
                </div>
            </div>
        </form>
        <div class="items my-4">
            <h2>Prescription</h2>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">SNo.</th>
                    <th scope="col">Medicine</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Dosage</th>
                    <th scope="col">Remove</th>
                  </tr>
                </thead>
                <tbody id="tableBody">
                  
                </tbody>
              </table>
        </div>
    </div>
    <script>
        function record(str)
        {
            var recognition = new webkitSpeechRecognition();
            recognition.lang = "en-US";
            recognition.maxAlternatives=10;
            recognition.onresult = function(event){
                console.log(document.getElementById(str).value = event.results[0][0].transcript);
                document.getElementById(str).value = event.results[0][0].transcript;
            }
            recognition.start();
        }

        add = document.getElementById('add');

        function getAndUpdate(){
            med = document.getElementById('medicine').value;
            quant = document.getElementById('quantity').value;
            dos = document.getElementById('dosage').value;
            if(sessionStorage.getItem('itemsJson')==null){
                itemJsonArray = [];
                itemJsonArray.push([med,quant,dos]);
                sessionStorage.setItem('itemsJson', JSON.stringify(itemJsonArray));
            }
            else{
                itemJsonArrayStr = sessionStorage.getItem('itemsJson');
                itemJsonArray = JSON.parse(itemJsonArrayStr);
                itemJsonArray.push([med,quant,dos]);
                sessionStorage.setItem('itemsJson', JSON.stringify(itemJsonArray));
            }
            update();
        }

        function update(){
            
            if(sessionStorage.getItem('itemsJson')==null){
                itemJsonArray = [];
                sessionStorage.setItem('itemsJson', JSON.stringify(itemJsonArray));
            }
            else{
                itemJsonArrayStr = sessionStorage.getItem('itemsJson');
                itemJsonArray = JSON.parse(itemJsonArrayStr);
            }

            let str = '';
            tableBody = document.getElementById('tableBody');
            itemJsonArray.forEach((element, index) => {
                str += `
                  <tr>
                    <th id="i${index+1}" scope="row">${index+1}</th>
                    <td id="m${index+1}">${element[0]}</td>
                    <td id="q${index+1}">${element[1]}</td>
                    <td id="d${index+1}">${element[2]}</td>
                    
                    <td><button class="btn btn-sm btn-primary" id="${index+1}" onclick="deleted(${index})">Delete</button></form>
                    </td>
                  </tr>`;
            });
            tableBody.innerHTML = str;
        }

        add.addEventListener('click',getAndUpdate);

        update();

        function deleted(itemIndex){
            var index=itemIndex;
            console.log('deleted', itemIndex);
            itemJsonArrayStr = sessionStorage.getItem('itemsJson');
            itemJsonArray = JSON.parse(itemJsonArrayStr);
            // delete itemIndex element from array
            itemJsonArray.splice(itemIndex,1);
            sessionStorage.setItem('itemsJson', JSON.stringify(itemJsonArray));
            update();
        }
        
        function prescription()
        {
            if(isset(search))
            // {
                itemJsonStr=sessionStorage.getItem('itemsJson');
                //const jsonString= JSON.(itemJsonStr);
                const xhr=new XMLHttpRequest();
                xhr.open("POST","receive.php");
                xhr.setRequestHeader("Content-type","application/json");
                sessionStorage.clear();
                xhr.send(itemJsonStr);
                // header('location: doctor.php');
            // }
        }
    </script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>

        <div class="mb-1 btnflex">
            <div class="btncontainer">
                <button type="submit" id="submitpr" class="btn btn-primary" onclick=prescription()>Submit</button>
            </div>
        </div>
</body>

</html>